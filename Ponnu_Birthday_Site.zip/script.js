setInterval(()=> {
  const h = document.createElement("div");
  h.className="heart";
  h.style.left=Math.random()*100+"vw";
  h.style.top=Math.random()*100+"vh";
  document.body.appendChild(h);
  setTimeout(()=>h.remove(),3000);
},400);
